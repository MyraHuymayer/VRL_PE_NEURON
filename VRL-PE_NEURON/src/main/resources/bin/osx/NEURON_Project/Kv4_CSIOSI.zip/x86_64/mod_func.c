#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _Kv4_csiosi_reg(void);
extern void _myseclamp_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," Kv4_csiosi.mod");
    fprintf(stderr," myseclamp.mod");
    fprintf(stderr, "\n");
  }
  _Kv4_csiosi_reg();
  _myseclamp_reg();
}
