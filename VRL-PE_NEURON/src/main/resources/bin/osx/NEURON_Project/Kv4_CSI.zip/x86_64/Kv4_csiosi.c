/* Created by Language version: 6.2.0 */
/* VECTORIZED */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define _threadargscomma_ _p, _ppvar, _thread, _nt,
#define _threadargs_ _p, _ppvar, _thread, _nt
 
#define _threadargsprotocomma_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt,
#define _threadargsproto_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 /* Thread safe. No static _p or _ppvar. */
 
#define t _nt->_t
#define dt _nt->_dt
#define gmax _p[0]
#define g _p[1]
#define C0 _p[2]
#define C1 _p[3]
#define C2 _p[4]
#define C3 _p[5]
#define C4 _p[6]
#define C5 _p[7]
#define I0 _p[8]
#define I1 _p[9]
#define I2 _p[10]
#define I3 _p[11]
#define I4 _p[12]
#define I5 _p[13]
#define O _p[14]
#define I6 _p[15]
#define I7 _p[16]
#define ek _p[17]
#define ik _p[18]
#define kC01f _p[19]
#define kC01b _p[20]
#define kC12f _p[21]
#define kC12b _p[22]
#define kC23f _p[23]
#define kC23b _p[24]
#define kC34f _p[25]
#define kC34b _p[26]
#define kC45f _p[27]
#define kC45b _p[28]
#define kCOf _p[29]
#define kCOb _p[30]
#define kCI0f _p[31]
#define kCI0b _p[32]
#define kCI1f _p[33]
#define kCI1b _p[34]
#define kCI2f _p[35]
#define kCI2b _p[36]
#define kCI3f _p[37]
#define kCI3b _p[38]
#define kCI4f _p[39]
#define kCI4b _p[40]
#define kCI5f _p[41]
#define kCI5b _p[42]
#define kI01f _p[43]
#define kI01b _p[44]
#define kI12f _p[45]
#define kI12b _p[46]
#define kI23f _p[47]
#define kI23b _p[48]
#define kI34f _p[49]
#define kI34b _p[50]
#define kI45f _p[51]
#define kI45b _p[52]
#define kOIf _p[53]
#define kOIb _p[54]
#define kII2f _p[55]
#define kII2b _p[56]
#define DC0 _p[57]
#define DC1 _p[58]
#define DC2 _p[59]
#define DC3 _p[60]
#define DC4 _p[61]
#define DC5 _p[62]
#define DI0 _p[63]
#define DI1 _p[64]
#define DI2 _p[65]
#define DI3 _p[66]
#define DI4 _p[67]
#define DI5 _p[68]
#define DO _p[69]
#define DI6 _p[70]
#define DI7 _p[71]
#define v _p[72]
#define _g _p[73]
#define _ion_ek	*_ppvar[0]._pval
#define _ion_ik	*_ppvar[1]._pval
#define _ion_dikdv	*_ppvar[2]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 static Datum* _extcall_thread;
 static Prop* _extcall_prop;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_rates(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_kv4csiosi", _hoc_setdata,
 "rates_kv4csiosi", _hoc_rates,
 0, 0
};
 /* declare global and static user variables */
#define F F_kv4csiosi
 double F = 96485;
#define R R_kv4csiosi
 double R = 8314.5;
#define a a_kv4csiosi
 double a = 7;
#define b b_kv4csiosi
 double b = 0.09;
#define c c_kv4csiosi
 double c = 1.01216;
#define d d_kv4csiosi
 double d = 2.49888;
#define f f_kv4csiosi
 double f = 0.27713;
#define ki2i ki2i_kv4csiosi
 double ki2i = 0.0333;
#define kii2 kii2_kv4csiosi
 double kii2 = 0.1475;
#define kio kio_kv4csiosi
 double kio = 0.0436;
#define koi koi_kv4csiosi
 double koi = 0.5195;
#define kic kic_kv4csiosi
 double kic = 0.00179355;
#define kci kci_kv4csiosi
 double kci = 0.1219;
#define k k_kv4csiosi
 double k = 7.69049;
#define l l_kv4csiosi
 double l = 4.38562;
#define q q_kv4csiosi
 double q = 1.01315;
#define zl zl_kv4csiosi
 double zl = -0.0709237;
#define zk zk_kv4csiosi
 double zk = 0.0550205;
#define zd zd_kv4csiosi
 double zd = -1.15467;
#define zc zc_kv4csiosi
 double zc = 0.500096;
#define zb zb_kv4csiosi
 double zb = -2.06228;
#define za za_kv4csiosi
 double za = 0.315647;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "a_kv4csiosi", "/ms",
 "b_kv4csiosi", "/ms",
 "c_kv4csiosi", "/ms",
 "d_kv4csiosi", "/ms",
 "k_kv4csiosi", "/ms",
 "l_kv4csiosi", "/ms",
 "kci_kv4csiosi", "/ms",
 "kic_kv4csiosi", "/ms",
 "koi_kv4csiosi", "/ms",
 "kio_kv4csiosi", "/ms",
 "kii2_kv4csiosi", "/ms",
 "ki2i_kv4csiosi", "/ms",
 "gmax_kv4csiosi", "S/cm2",
 "g_kv4csiosi", "S/cm2",
 0,0
};
 static double C50 = 0;
 static double C40 = 0;
 static double C30 = 0;
 static double C20 = 0;
 static double C10 = 0;
 static double C00 = 0;
 static double I70 = 0;
 static double I60 = 0;
 static double I50 = 0;
 static double I40 = 0;
 static double I30 = 0;
 static double I20 = 0;
 static double I10 = 0;
 static double I00 = 0;
 static double O0 = 0;
 static double delta_t = 0.01;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "F_kv4csiosi", &F_kv4csiosi,
 "R_kv4csiosi", &R_kv4csiosi,
 "a_kv4csiosi", &a_kv4csiosi,
 "za_kv4csiosi", &za_kv4csiosi,
 "b_kv4csiosi", &b_kv4csiosi,
 "zb_kv4csiosi", &zb_kv4csiosi,
 "c_kv4csiosi", &c_kv4csiosi,
 "zc_kv4csiosi", &zc_kv4csiosi,
 "d_kv4csiosi", &d_kv4csiosi,
 "zd_kv4csiosi", &zd_kv4csiosi,
 "k_kv4csiosi", &k_kv4csiosi,
 "zk_kv4csiosi", &zk_kv4csiosi,
 "l_kv4csiosi", &l_kv4csiosi,
 "zl_kv4csiosi", &zl_kv4csiosi,
 "f_kv4csiosi", &f_kv4csiosi,
 "q_kv4csiosi", &q_kv4csiosi,
 "kci_kv4csiosi", &kci_kv4csiosi,
 "kic_kv4csiosi", &kic_kv4csiosi,
 "koi_kv4csiosi", &koi_kv4csiosi,
 "kio_kv4csiosi", &kio_kv4csiosi,
 "kii2_kv4csiosi", &kii2_kv4csiosi,
 "ki2i_kv4csiosi", &ki2i_kv4csiosi,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[3]._i
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "6.2.0",
"kv4csiosi",
 "gmax_kv4csiosi",
 0,
 "g_kv4csiosi",
 0,
 "C0_kv4csiosi",
 "C1_kv4csiosi",
 "C2_kv4csiosi",
 "C3_kv4csiosi",
 "C4_kv4csiosi",
 "C5_kv4csiosi",
 "I0_kv4csiosi",
 "I1_kv4csiosi",
 "I2_kv4csiosi",
 "I3_kv4csiosi",
 "I4_kv4csiosi",
 "I5_kv4csiosi",
 "O_kv4csiosi",
 "I6_kv4csiosi",
 "I7_kv4csiosi",
 0,
 0};
 static Symbol* _k_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 74, _prop);
 	/*initialize range parameters*/
 	gmax = 0;
 	_prop->param = _p;
 	_prop->param_size = 74;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 4, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_k_sym);
 nrn_promote(prop_ion, 0, 1);
 	_ppvar[0]._pval = &prop_ion->param[0]; /* ek */
 	_ppvar[1]._pval = &prop_ion->param[3]; /* ik */
 	_ppvar[2]._pval = &prop_ion->param[4]; /* _ion_dikdv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 static void _thread_cleanup(Datum*);
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*f)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _Kv4_csiosi_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("k", -10000.);
 	_k_sym = hoc_lookup("k_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 3);
  _extcall_thread = (Datum*)ecalloc(2, sizeof(Datum));
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 0, _thread_cleanup);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
  hoc_register_dparam_size(_mechtype, 4);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 kv4csiosi /Users/myra/NEURON-Projects/Parameter_Estimation/VRL-Plugin/VRL-PE_NEURON/src/main/resources/bin/osx/NEURON_Project/x86_64/Kv4_csiosi.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rates(_threadargsprotocomma_ double);
 extern double *_nrn_thread_getelm();
 
#define _MATELM1(_row,_col) *(_nrn_thread_getelm(_so, _row + 1, _col + 1))
 
#define _RHS1(_arg) _rhs[_arg+1]
  
#define _linmat1  1
 static int _spth1 = 1;
 static int _cvspth1 = 0;
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static int _slist1[15], _dlist1[15]; static double *_temp1;
 static int states();
 
static int states (void* _so, double* _rhs, double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt)
 {int _reset=0;
 {
   double b_flux, f_flux, _term; int _i;
 {int _i; double _dt1 = 1.0/dt;
for(_i=1;_i<15;_i++){
  	_RHS1(_i) = -_dt1*(_p[_slist1[_i]] - _p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
} }
 rates ( _threadargscomma_ v ) ;
   /* ~ C0 <-> C1 ( kC01f , kC01b )*/
 f_flux =  kC01f * C0 ;
 b_flux =  kC01b * C1 ;
 _RHS1( 6) -= (f_flux - b_flux);
 _RHS1( 5) += (f_flux - b_flux);
 
 _term =  kC01f ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 5 ,6)  -= _term;
 _term =  kC01b ;
 _MATELM1( 6 ,5)  -= _term;
 _MATELM1( 5 ,5)  += _term;
 /*REACTION*/
  /* ~ C1 <-> C2 ( kC12f , kC12b )*/
 f_flux =  kC12f * C1 ;
 b_flux =  kC12b * C2 ;
 _RHS1( 5) -= (f_flux - b_flux);
 _RHS1( 4) += (f_flux - b_flux);
 
 _term =  kC12f ;
 _MATELM1( 5 ,5)  += _term;
 _MATELM1( 4 ,5)  -= _term;
 _term =  kC12b ;
 _MATELM1( 5 ,4)  -= _term;
 _MATELM1( 4 ,4)  += _term;
 /*REACTION*/
  /* ~ C2 <-> C3 ( kC23f , kC23b )*/
 f_flux =  kC23f * C2 ;
 b_flux =  kC23b * C3 ;
 _RHS1( 4) -= (f_flux - b_flux);
 _RHS1( 3) += (f_flux - b_flux);
 
 _term =  kC23f ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 3 ,4)  -= _term;
 _term =  kC23b ;
 _MATELM1( 4 ,3)  -= _term;
 _MATELM1( 3 ,3)  += _term;
 /*REACTION*/
  /* ~ C3 <-> C4 ( kC34f , kC34b )*/
 f_flux =  kC34f * C3 ;
 b_flux =  kC34b * C4 ;
 _RHS1( 3) -= (f_flux - b_flux);
 _RHS1( 2) += (f_flux - b_flux);
 
 _term =  kC34f ;
 _MATELM1( 3 ,3)  += _term;
 _MATELM1( 2 ,3)  -= _term;
 _term =  kC34b ;
 _MATELM1( 3 ,2)  -= _term;
 _MATELM1( 2 ,2)  += _term;
 /*REACTION*/
  /* ~ C4 <-> C5 ( kC45f , kC45b )*/
 f_flux =  kC45f * C4 ;
 b_flux =  kC45b * C5 ;
 _RHS1( 2) -= (f_flux - b_flux);
 _RHS1( 1) += (f_flux - b_flux);
 
 _term =  kC45f ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 1 ,2)  -= _term;
 _term =  kC45b ;
 _MATELM1( 2 ,1)  -= _term;
 _MATELM1( 1 ,1)  += _term;
 /*REACTION*/
  /* ~ C5 <-> O ( kCOf , kCOb )*/
 f_flux =  kCOf * C5 ;
 b_flux =  kCOb * O ;
 _RHS1( 1) -= (f_flux - b_flux);
 _RHS1( 14) += (f_flux - b_flux);
 
 _term =  kCOf ;
 _MATELM1( 1 ,1)  += _term;
 _MATELM1( 14 ,1)  -= _term;
 _term =  kCOb ;
 _MATELM1( 1 ,14)  -= _term;
 _MATELM1( 14 ,14)  += _term;
 /*REACTION*/
  /* ~ C0 <-> I0 ( kCI0f , kCI0b )*/
 f_flux =  kCI0f * C0 ;
 b_flux =  kCI0b * I0 ;
 _RHS1( 6) -= (f_flux - b_flux);
 _RHS1( 13) += (f_flux - b_flux);
 
 _term =  kCI0f ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 13 ,6)  -= _term;
 _term =  kCI0b ;
 _MATELM1( 6 ,13)  -= _term;
 _MATELM1( 13 ,13)  += _term;
 /*REACTION*/
  /* ~ C1 <-> I1 ( kCI1f , kCI1b )*/
 f_flux =  kCI1f * C1 ;
 b_flux =  kCI1b * I1 ;
 _RHS1( 5) -= (f_flux - b_flux);
 _RHS1( 12) += (f_flux - b_flux);
 
 _term =  kCI1f ;
 _MATELM1( 5 ,5)  += _term;
 _MATELM1( 12 ,5)  -= _term;
 _term =  kCI1b ;
 _MATELM1( 5 ,12)  -= _term;
 _MATELM1( 12 ,12)  += _term;
 /*REACTION*/
  /* ~ C2 <-> I2 ( kCI2f , kCI2b )*/
 f_flux =  kCI2f * C2 ;
 b_flux =  kCI2b * I2 ;
 _RHS1( 4) -= (f_flux - b_flux);
 _RHS1( 11) += (f_flux - b_flux);
 
 _term =  kCI2f ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 11 ,4)  -= _term;
 _term =  kCI2b ;
 _MATELM1( 4 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ C3 <-> I3 ( kCI3f , kCI3b )*/
 f_flux =  kCI3f * C3 ;
 b_flux =  kCI3b * I3 ;
 _RHS1( 3) -= (f_flux - b_flux);
 _RHS1( 10) += (f_flux - b_flux);
 
 _term =  kCI3f ;
 _MATELM1( 3 ,3)  += _term;
 _MATELM1( 10 ,3)  -= _term;
 _term =  kCI3b ;
 _MATELM1( 3 ,10)  -= _term;
 _MATELM1( 10 ,10)  += _term;
 /*REACTION*/
  /* ~ C4 <-> I4 ( kCI4f , kCI4b )*/
 f_flux =  kCI4f * C4 ;
 b_flux =  kCI4b * I4 ;
 _RHS1( 2) -= (f_flux - b_flux);
 _RHS1( 9) += (f_flux - b_flux);
 
 _term =  kCI4f ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 9 ,2)  -= _term;
 _term =  kCI4b ;
 _MATELM1( 2 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ C5 <-> I5 ( kCI5f , kCI5b )*/
 f_flux =  kCI5f * C5 ;
 b_flux =  kCI5b * I5 ;
 _RHS1( 1) -= (f_flux - b_flux);
 _RHS1( 8) += (f_flux - b_flux);
 
 _term =  kCI5f ;
 _MATELM1( 1 ,1)  += _term;
 _MATELM1( 8 ,1)  -= _term;
 _term =  kCI5b ;
 _MATELM1( 1 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ I0 <-> I1 ( kI01f , kI01b )*/
 f_flux =  kI01f * I0 ;
 b_flux =  kI01b * I1 ;
 _RHS1( 13) -= (f_flux - b_flux);
 _RHS1( 12) += (f_flux - b_flux);
 
 _term =  kI01f ;
 _MATELM1( 13 ,13)  += _term;
 _MATELM1( 12 ,13)  -= _term;
 _term =  kI01b ;
 _MATELM1( 13 ,12)  -= _term;
 _MATELM1( 12 ,12)  += _term;
 /*REACTION*/
  /* ~ I1 <-> I2 ( kI12f , kI12b )*/
 f_flux =  kI12f * I1 ;
 b_flux =  kI12b * I2 ;
 _RHS1( 12) -= (f_flux - b_flux);
 _RHS1( 11) += (f_flux - b_flux);
 
 _term =  kI12f ;
 _MATELM1( 12 ,12)  += _term;
 _MATELM1( 11 ,12)  -= _term;
 _term =  kI12b ;
 _MATELM1( 12 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ I2 <-> I3 ( kI23f , kI23b )*/
 f_flux =  kI23f * I2 ;
 b_flux =  kI23b * I3 ;
 _RHS1( 11) -= (f_flux - b_flux);
 _RHS1( 10) += (f_flux - b_flux);
 
 _term =  kI23f ;
 _MATELM1( 11 ,11)  += _term;
 _MATELM1( 10 ,11)  -= _term;
 _term =  kI23b ;
 _MATELM1( 11 ,10)  -= _term;
 _MATELM1( 10 ,10)  += _term;
 /*REACTION*/
  /* ~ I3 <-> I4 ( kI34f , kI34b )*/
 f_flux =  kI34f * I3 ;
 b_flux =  kI34b * I4 ;
 _RHS1( 10) -= (f_flux - b_flux);
 _RHS1( 9) += (f_flux - b_flux);
 
 _term =  kI34f ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 9 ,10)  -= _term;
 _term =  kI34b ;
 _MATELM1( 10 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ I4 <-> I5 ( kI45f , kI45b )*/
 f_flux =  kI45f * I4 ;
 b_flux =  kI45b * I5 ;
 _RHS1( 9) -= (f_flux - b_flux);
 _RHS1( 8) += (f_flux - b_flux);
 
 _term =  kI45f ;
 _MATELM1( 9 ,9)  += _term;
 _MATELM1( 8 ,9)  -= _term;
 _term =  kI45b ;
 _MATELM1( 9 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ O <-> I6 ( kOIf , kOIb )*/
 f_flux =  kOIf * O ;
 b_flux =  kOIb * I6 ;
 _RHS1( 14) -= (f_flux - b_flux);
 _RHS1( 7) += (f_flux - b_flux);
 
 _term =  kOIf ;
 _MATELM1( 14 ,14)  += _term;
 _MATELM1( 7 ,14)  -= _term;
 _term =  kOIb ;
 _MATELM1( 14 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ I6 <-> I7 ( kII2f , kII2b )*/
 f_flux =  kII2f * I6 ;
 b_flux =  kII2b * I7 ;
 _RHS1( 7) -= (f_flux - b_flux);
 
 _term =  kII2f ;
 _MATELM1( 7 ,7)  += _term;
 _term =  kII2b ;
 _MATELM1( 7 ,0)  -= _term;
 /*REACTION*/
   /* C0 + C1 + C2 + C3 + C4 + C5 + I0 + I1 + I2 + I3 + I4 + I5 + O + I6 + I7 = 1.0 */
 _RHS1(0) =  1.0;
 _MATELM1(0, 0) = 1;
 _RHS1(0) -= I7 ;
 _MATELM1(0, 7) = 1;
 _RHS1(0) -= I6 ;
 _MATELM1(0, 14) = 1;
 _RHS1(0) -= O ;
 _MATELM1(0, 8) = 1;
 _RHS1(0) -= I5 ;
 _MATELM1(0, 9) = 1;
 _RHS1(0) -= I4 ;
 _MATELM1(0, 10) = 1;
 _RHS1(0) -= I3 ;
 _MATELM1(0, 11) = 1;
 _RHS1(0) -= I2 ;
 _MATELM1(0, 12) = 1;
 _RHS1(0) -= I1 ;
 _MATELM1(0, 13) = 1;
 _RHS1(0) -= I0 ;
 _MATELM1(0, 1) = 1;
 _RHS1(0) -= C5 ;
 _MATELM1(0, 2) = 1;
 _RHS1(0) -= C4 ;
 _MATELM1(0, 3) = 1;
 _RHS1(0) -= C3 ;
 _MATELM1(0, 4) = 1;
 _RHS1(0) -= C2 ;
 _MATELM1(0, 5) = 1;
 _RHS1(0) -= C1 ;
 _MATELM1(0, 6) = 1;
 _RHS1(0) -= C0 ;
 /*CONSERVATION*/
   } return _reset;
 }
 
static int  rates ( _threadargsprotocomma_ double _lv ) {
   kC01f = 4.0 * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC01b = b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC12f = 3.0 * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC12b = 2.0 * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC23f = 2.0 * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC23b = 3.0 * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC34f = a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC34b = 4.0 * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC45f = c * exp ( zc * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kC45b = d * exp ( zd * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kCOf = k * exp ( zk * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kCOb = l * exp ( zl * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kCI0f = kci * ( pow( f , 4.0 ) ) ;
   kCI0b = kic / ( pow( f , 4.0 ) ) ;
   kCI1f = kci * ( pow( f , 3.0 ) ) ;
   kCI1b = kic / ( pow( f , 3.0 ) ) ;
   kCI2f = kci * ( pow( f , 2.0 ) ) ;
   kCI2b = kic / ( pow( f , 2.0 ) ) ;
   kCI3f = kci * ( f ) ;
   kCI3b = kic / ( f ) ;
   kCI4f = kci ;
   kCI4b = kic ;
   kCI5f = kci * q ;
   kCI5b = kic / q ;
   kI01f = 4.0 * ( 1.0 / f ) * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI01b = d * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI12f = 3.0 * ( 1.0 / f ) * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI12b = 2.0 * f * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI23f = 2.0 * ( 1.0 / f ) * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI23b = 3.0 * f * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI34f = ( 1.0 / f ) * a * exp ( za * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI34b = 4.0 * f * b * exp ( zb * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI45f = q * c * exp ( zc * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kI45b = ( 1.0 / q ) * d * exp ( zd * _lv * F / ( R * ( 273.16 + celsius ) ) ) ;
   kOIf = koi ;
   kOIb = kio ;
   kII2f = kii2 ;
   kII2b = ki2i ;
    return 0; }
 
static void _hoc_rates(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r = 1.;
 rates ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
/*CVODE ode begin*/
 static int _ode_spec1(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset=0;{
 double b_flux, f_flux, _term; int _i;
 {int _i; for(_i=0;_i<15;_i++) _p[_dlist1[_i]] = 0.0;}
 rates ( _threadargscomma_ v ) ;
 /* ~ C0 <-> C1 ( kC01f , kC01b )*/
 f_flux =  kC01f * C0 ;
 b_flux =  kC01b * C1 ;
 DC0 -= (f_flux - b_flux);
 DC1 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C1 <-> C2 ( kC12f , kC12b )*/
 f_flux =  kC12f * C1 ;
 b_flux =  kC12b * C2 ;
 DC1 -= (f_flux - b_flux);
 DC2 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C2 <-> C3 ( kC23f , kC23b )*/
 f_flux =  kC23f * C2 ;
 b_flux =  kC23b * C3 ;
 DC2 -= (f_flux - b_flux);
 DC3 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C3 <-> C4 ( kC34f , kC34b )*/
 f_flux =  kC34f * C3 ;
 b_flux =  kC34b * C4 ;
 DC3 -= (f_flux - b_flux);
 DC4 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C4 <-> C5 ( kC45f , kC45b )*/
 f_flux =  kC45f * C4 ;
 b_flux =  kC45b * C5 ;
 DC4 -= (f_flux - b_flux);
 DC5 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C5 <-> O ( kCOf , kCOb )*/
 f_flux =  kCOf * C5 ;
 b_flux =  kCOb * O ;
 DC5 -= (f_flux - b_flux);
 DO += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C0 <-> I0 ( kCI0f , kCI0b )*/
 f_flux =  kCI0f * C0 ;
 b_flux =  kCI0b * I0 ;
 DC0 -= (f_flux - b_flux);
 DI0 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C1 <-> I1 ( kCI1f , kCI1b )*/
 f_flux =  kCI1f * C1 ;
 b_flux =  kCI1b * I1 ;
 DC1 -= (f_flux - b_flux);
 DI1 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C2 <-> I2 ( kCI2f , kCI2b )*/
 f_flux =  kCI2f * C2 ;
 b_flux =  kCI2b * I2 ;
 DC2 -= (f_flux - b_flux);
 DI2 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C3 <-> I3 ( kCI3f , kCI3b )*/
 f_flux =  kCI3f * C3 ;
 b_flux =  kCI3b * I3 ;
 DC3 -= (f_flux - b_flux);
 DI3 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C4 <-> I4 ( kCI4f , kCI4b )*/
 f_flux =  kCI4f * C4 ;
 b_flux =  kCI4b * I4 ;
 DC4 -= (f_flux - b_flux);
 DI4 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ C5 <-> I5 ( kCI5f , kCI5b )*/
 f_flux =  kCI5f * C5 ;
 b_flux =  kCI5b * I5 ;
 DC5 -= (f_flux - b_flux);
 DI5 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I0 <-> I1 ( kI01f , kI01b )*/
 f_flux =  kI01f * I0 ;
 b_flux =  kI01b * I1 ;
 DI0 -= (f_flux - b_flux);
 DI1 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I1 <-> I2 ( kI12f , kI12b )*/
 f_flux =  kI12f * I1 ;
 b_flux =  kI12b * I2 ;
 DI1 -= (f_flux - b_flux);
 DI2 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I2 <-> I3 ( kI23f , kI23b )*/
 f_flux =  kI23f * I2 ;
 b_flux =  kI23b * I3 ;
 DI2 -= (f_flux - b_flux);
 DI3 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I3 <-> I4 ( kI34f , kI34b )*/
 f_flux =  kI34f * I3 ;
 b_flux =  kI34b * I4 ;
 DI3 -= (f_flux - b_flux);
 DI4 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I4 <-> I5 ( kI45f , kI45b )*/
 f_flux =  kI45f * I4 ;
 b_flux =  kI45b * I5 ;
 DI4 -= (f_flux - b_flux);
 DI5 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ O <-> I6 ( kOIf , kOIb )*/
 f_flux =  kOIf * O ;
 b_flux =  kOIb * I6 ;
 DO -= (f_flux - b_flux);
 DI6 += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ I6 <-> I7 ( kII2f , kII2b )*/
 f_flux =  kII2f * I6 ;
 b_flux =  kII2b * I7 ;
 DI6 -= (f_flux - b_flux);
 DI7 += (f_flux - b_flux);
 
 /*REACTION*/
   /* C0 + C1 + C2 + C3 + C4 + C5 + I0 + I1 + I2 + I3 + I4 + I5 + O + I6 + I7 = 1.0 */
 /*CONSERVATION*/
   } return _reset;
 }
 
/*CVODE matsol*/
 static int _ode_matsol1(void* _so, double* _rhs, double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset=0;{
 double b_flux, f_flux, _term; int _i;
   b_flux = f_flux = 0.;
 {int _i; double _dt1 = 1.0/dt;
for(_i=0;_i<15;_i++){
  	_RHS1(_i) = _dt1*(_p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
} }
 rates ( _threadargscomma_ v ) ;
 /* ~ C0 <-> C1 ( kC01f , kC01b )*/
 _term =  kC01f ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 5 ,6)  -= _term;
 _term =  kC01b ;
 _MATELM1( 6 ,5)  -= _term;
 _MATELM1( 5 ,5)  += _term;
 /*REACTION*/
  /* ~ C1 <-> C2 ( kC12f , kC12b )*/
 _term =  kC12f ;
 _MATELM1( 5 ,5)  += _term;
 _MATELM1( 4 ,5)  -= _term;
 _term =  kC12b ;
 _MATELM1( 5 ,4)  -= _term;
 _MATELM1( 4 ,4)  += _term;
 /*REACTION*/
  /* ~ C2 <-> C3 ( kC23f , kC23b )*/
 _term =  kC23f ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 3 ,4)  -= _term;
 _term =  kC23b ;
 _MATELM1( 4 ,3)  -= _term;
 _MATELM1( 3 ,3)  += _term;
 /*REACTION*/
  /* ~ C3 <-> C4 ( kC34f , kC34b )*/
 _term =  kC34f ;
 _MATELM1( 3 ,3)  += _term;
 _MATELM1( 2 ,3)  -= _term;
 _term =  kC34b ;
 _MATELM1( 3 ,2)  -= _term;
 _MATELM1( 2 ,2)  += _term;
 /*REACTION*/
  /* ~ C4 <-> C5 ( kC45f , kC45b )*/
 _term =  kC45f ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 1 ,2)  -= _term;
 _term =  kC45b ;
 _MATELM1( 2 ,1)  -= _term;
 _MATELM1( 1 ,1)  += _term;
 /*REACTION*/
  /* ~ C5 <-> O ( kCOf , kCOb )*/
 _term =  kCOf ;
 _MATELM1( 1 ,1)  += _term;
 _MATELM1( 14 ,1)  -= _term;
 _term =  kCOb ;
 _MATELM1( 1 ,14)  -= _term;
 _MATELM1( 14 ,14)  += _term;
 /*REACTION*/
  /* ~ C0 <-> I0 ( kCI0f , kCI0b )*/
 _term =  kCI0f ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 13 ,6)  -= _term;
 _term =  kCI0b ;
 _MATELM1( 6 ,13)  -= _term;
 _MATELM1( 13 ,13)  += _term;
 /*REACTION*/
  /* ~ C1 <-> I1 ( kCI1f , kCI1b )*/
 _term =  kCI1f ;
 _MATELM1( 5 ,5)  += _term;
 _MATELM1( 12 ,5)  -= _term;
 _term =  kCI1b ;
 _MATELM1( 5 ,12)  -= _term;
 _MATELM1( 12 ,12)  += _term;
 /*REACTION*/
  /* ~ C2 <-> I2 ( kCI2f , kCI2b )*/
 _term =  kCI2f ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 11 ,4)  -= _term;
 _term =  kCI2b ;
 _MATELM1( 4 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ C3 <-> I3 ( kCI3f , kCI3b )*/
 _term =  kCI3f ;
 _MATELM1( 3 ,3)  += _term;
 _MATELM1( 10 ,3)  -= _term;
 _term =  kCI3b ;
 _MATELM1( 3 ,10)  -= _term;
 _MATELM1( 10 ,10)  += _term;
 /*REACTION*/
  /* ~ C4 <-> I4 ( kCI4f , kCI4b )*/
 _term =  kCI4f ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 9 ,2)  -= _term;
 _term =  kCI4b ;
 _MATELM1( 2 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ C5 <-> I5 ( kCI5f , kCI5b )*/
 _term =  kCI5f ;
 _MATELM1( 1 ,1)  += _term;
 _MATELM1( 8 ,1)  -= _term;
 _term =  kCI5b ;
 _MATELM1( 1 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ I0 <-> I1 ( kI01f , kI01b )*/
 _term =  kI01f ;
 _MATELM1( 13 ,13)  += _term;
 _MATELM1( 12 ,13)  -= _term;
 _term =  kI01b ;
 _MATELM1( 13 ,12)  -= _term;
 _MATELM1( 12 ,12)  += _term;
 /*REACTION*/
  /* ~ I1 <-> I2 ( kI12f , kI12b )*/
 _term =  kI12f ;
 _MATELM1( 12 ,12)  += _term;
 _MATELM1( 11 ,12)  -= _term;
 _term =  kI12b ;
 _MATELM1( 12 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ I2 <-> I3 ( kI23f , kI23b )*/
 _term =  kI23f ;
 _MATELM1( 11 ,11)  += _term;
 _MATELM1( 10 ,11)  -= _term;
 _term =  kI23b ;
 _MATELM1( 11 ,10)  -= _term;
 _MATELM1( 10 ,10)  += _term;
 /*REACTION*/
  /* ~ I3 <-> I4 ( kI34f , kI34b )*/
 _term =  kI34f ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 9 ,10)  -= _term;
 _term =  kI34b ;
 _MATELM1( 10 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ I4 <-> I5 ( kI45f , kI45b )*/
 _term =  kI45f ;
 _MATELM1( 9 ,9)  += _term;
 _MATELM1( 8 ,9)  -= _term;
 _term =  kI45b ;
 _MATELM1( 9 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ O <-> I6 ( kOIf , kOIb )*/
 _term =  kOIf ;
 _MATELM1( 14 ,14)  += _term;
 _MATELM1( 7 ,14)  -= _term;
 _term =  kOIb ;
 _MATELM1( 14 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ I6 <-> I7 ( kII2f , kII2b )*/
 _term =  kII2f ;
 _MATELM1( 7 ,7)  += _term;
 _MATELM1( 0 ,7)  -= _term;
 _term =  kII2b ;
 _MATELM1( 7 ,0)  -= _term;
 _MATELM1( 0 ,0)  += _term;
 /*REACTION*/
   /* C0 + C1 + C2 + C3 + C4 + C5 + I0 + I1 + I2 + I3 + I4 + I5 + O + I6 + I7 = 1.0 */
 /*CONSERVATION*/
   } return _reset;
 }
 
/*CVODE end*/
 
static int _ode_count(int _type){ return 15;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  ek = _ion_ek;
     _ode_spec1 (_p, _ppvar, _thread, _nt);
  }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
	double* _p; Datum* _ppvar;
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 15; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  ek = _ion_ek;
 _cvode_sparse_thread(&_thread[_cvspth1]._pvoid, 15, _dlist1, _p, _ode_matsol1, _ppvar, _thread, _nt);
 }}
 
static void _thread_cleanup(Datum* _thread) {
   _nrn_destroy_sparseobj_thread(_thread[_cvspth1]._pvoid);
   _nrn_destroy_sparseobj_thread(_thread[_spth1]._pvoid);
 }
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_k_sym, _ppvar, 0, 0);
   nrn_update_ion_pointer(_k_sym, _ppvar, 1, 3);
   nrn_update_ion_pointer(_k_sym, _ppvar, 2, 4);
 }

static void initmodel(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
  int _i; double _save;{
  C5 = C50;
  C4 = C40;
  C3 = C30;
  C2 = C20;
  C1 = C10;
  C0 = C00;
  I7 = I70;
  I6 = I60;
  I5 = I50;
  I4 = I40;
  I3 = I30;
  I2 = I20;
  I1 = I10;
  I0 = I00;
  O = O0;
 {
    _ss_sparse_thread(&_thread[_spth1]._pvoid, 15, _slist1, _dlist1, _p, &t, dt, states, _linmat1, _ppvar, _thread, _nt);
  }
 
}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
  ek = _ion_ek;
 initmodel(_p, _ppvar, _thread, _nt);
 }}

static double _nrn_current(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt, double _v){double _current=0.;v=_v;{ {
   g = gmax * O ;
   ik = g * ( v - ek ) ;
   }
 _current += ik;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
  ek = _ion_ek;
 _g = _nrn_current(_p, _ppvar, _thread, _nt, _v + .001);
 	{ double _dik;
  _dik = ik;
 _rhs = _nrn_current(_p, _ppvar, _thread, _nt, _v);
  _ion_dikdv += (_dik - ik)/.001 ;
 	}
 _g = (_g - _rhs)/.001;
  _ion_ik += ik ;
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type) {
 double _break, _save;
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
  ek = _ion_ek;
 { {
 for (; t < _break; t += dt) {
  sparse_thread(&_thread[_spth1]._pvoid, 15, _slist1, _dlist1, _p, &t, dt, states, _linmat1, _ppvar, _thread, _nt);
  
}}
 t = _save;
 } }}

}

static void terminal(){}

static void _initlists(){
 double _x; double* _p = &_x;
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(I7) - _p;  _dlist1[0] = &(DI7) - _p;
 _slist1[1] = &(C5) - _p;  _dlist1[1] = &(DC5) - _p;
 _slist1[2] = &(C4) - _p;  _dlist1[2] = &(DC4) - _p;
 _slist1[3] = &(C3) - _p;  _dlist1[3] = &(DC3) - _p;
 _slist1[4] = &(C2) - _p;  _dlist1[4] = &(DC2) - _p;
 _slist1[5] = &(C1) - _p;  _dlist1[5] = &(DC1) - _p;
 _slist1[6] = &(C0) - _p;  _dlist1[6] = &(DC0) - _p;
 _slist1[7] = &(I6) - _p;  _dlist1[7] = &(DI6) - _p;
 _slist1[8] = &(I5) - _p;  _dlist1[8] = &(DI5) - _p;
 _slist1[9] = &(I4) - _p;  _dlist1[9] = &(DI4) - _p;
 _slist1[10] = &(I3) - _p;  _dlist1[10] = &(DI3) - _p;
 _slist1[11] = &(I2) - _p;  _dlist1[11] = &(DI2) - _p;
 _slist1[12] = &(I1) - _p;  _dlist1[12] = &(DI1) - _p;
 _slist1[13] = &(I0) - _p;  _dlist1[13] = &(DI0) - _p;
 _slist1[14] = &(O) - _p;  _dlist1[14] = &(DO) - _p;
_first = 0;
}

#if defined(__cplusplus)
} /* extern "C" */
#endif
